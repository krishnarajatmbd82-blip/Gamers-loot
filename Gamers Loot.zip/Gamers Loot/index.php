<?php require_once 'common/header.php'; 
$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['join_tournament'])) {
    $tid = $_POST['tournament_id'];
    $fee = $_POST['entry_fee'];
    $uid = $_SESSION['user_id'];

    // Check balance and if already joined
    $stmt = $pdo->prepare("SELECT * FROM participants WHERE user_id = ? AND tournament_id = ?");
    $stmt->execute([$uid, $tid]);
    if ($stmt->rowCount() > 0) {
        $msg = "<div class='bg-yellow-500 text-gray-900 p-2 rounded mb-4'>You have already joined this tournament.</div>";
    } elseif ($balance < $fee) {
        $msg = "<div class='bg-red-500 text-white p-2 rounded mb-4'>Insufficient balance. Add money to wallet.</div>";
    } else {
        try {
            $pdo->beginTransaction();
            $pdo->exec("UPDATE users SET wallet_balance = wallet_balance - $fee WHERE id = $uid");
            $stmt = $pdo->prepare("INSERT INTO participants (user_id, tournament_id) VALUES (?, ?)");
            $stmt->execute([$uid, $tid]);
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'debit', ?)");
            $desc = "Joined Tournament #$tid";
            $stmt->execute([$uid, $fee, $desc]);
            $pdo->commit();
            $msg = "<div class='bg-green-500 text-white p-2 rounded mb-4'>Successfully joined the tournament!</div>";
        } catch(Exception $e) {
            $pdo->rollBack();
            $msg = "<div class='bg-red-500 text-white p-2 rounded mb-4'>Error joining tournament.</div>";
        }
    }
}

$stmt = $pdo->query("SELECT * FROM tournaments WHERE status = 'Upcoming' ORDER BY match_time ASC");
$tournaments = $stmt->fetchAll();
?>
<h2 class="text-xl font-bold mb-4">Upcoming Tournaments</h2>
<?= $msg ?>
<div class="space-y-4">
    <?php foreach($tournaments as $t): 
        $t_id = $t['id'];
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM participants WHERE tournament_id = ?");
        $stmt->execute([$t_id]);
        $joined_count = $stmt->fetchColumn();
    ?>
    <div class="bg-gray-800 p-4 rounded-lg shadow border border-gray-700">
        <div class="flex justify-between items-start mb-2">
            <div>
                <h3 class="font-bold text-lg text-yellow-500"><?= htmlspecialchars($t['title']) ?></h3>
                <p class="text-xs text-gray-400"><i class="fa-solid fa-gamepad"></i> <?= htmlspecialchars($t['game_name']) ?></p>
            </div>
            <div class="text-right">
                <p class="text-xs text-gray-400">Match Time</p>
                <p class="text-sm font-semibold"><?= date('d M, h:i A', strtotime($t['match_time'])) ?></p>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-2 mb-4 bg-gray-900 p-2 rounded">
            <div class="text-center"><p class="text-xs text-gray-400">Entry Fee</p><p class="font-bold text-green-400">₹<?= $t['entry_fee'] ?></p></div>
            <div class="text-center border-l border-gray-700"><p class="text-xs text-gray-400">Prize Pool</p><p class="font-bold text-yellow-500">₹<?= $t['prize_pool'] ?></p></div>
        </div>
        <div class="flex items-center justify-between">
            <span class="text-xs text-gray-400"><i class="fa-solid fa-users"></i> <?= $joined_count ?> Joined</span>
            <form method="POST">
                <input type="hidden" name="tournament_id" value="<?= $t['id'] ?>">
                <input type="hidden" name="entry_fee" value="<?= $t['entry_fee'] ?>">
                <button type="submit" name="join_tournament" class="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold px-6 py-2 rounded-full text-sm">Join Now</button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
    <?php if(!$tournaments): ?>
        <p class="text-gray-400 text-center mt-10">No upcoming tournaments available.</p>
    <?php endif; ?>
</div>
<?php require_once 'common/bottom.php'; ?>
