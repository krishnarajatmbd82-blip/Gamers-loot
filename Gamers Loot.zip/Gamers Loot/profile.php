<?php require_once 'common/header.php'; 
$uid = $_SESSION['user_id'];
$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $email = htmlspecialchars($_POST['email']);
    $upi = htmlspecialchars($_POST['upi_id']);
    $stmt = $pdo->prepare("UPDATE users SET email = ?, upi_id = ? WHERE id = ?");
    $stmt->execute([$email, $upi, $uid]);
    $msg = "<div class='bg-green-500 text-white p-2 rounded mb-4'>Profile Updated!</div>";
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$uid]);
$user = $stmt->fetch();
?>
<h2 class="text-xl font-bold mb-4">My Profile</h2>
<?= $msg ?>
<div class="bg-gray-800 p-4 rounded-lg shadow mb-6">
    <form method="POST" class="space-y-4">
        <div>
            <label class="text-xs text-gray-400 block mb-1">Username</label>
            <input type="text" value="<?= $user['username'] ?>" disabled class="w-full bg-gray-900 p-3 rounded text-gray-500 border border-gray-700">
        </div>
        <div>
            <label class="text-xs text-gray-400 block mb-1">Email Address</label>
            <input type="email" name="email" value="<?= $user['email'] ?>" class="w-full bg-gray-900 p-3 rounded text-white border border-gray-700">
        </div>
        <div>
            <label class="text-xs text-gray-400 block mb-1">Your UPI ID (For Withdrawals)</label>
            <input type="text" name="upi_id" value="<?= $user['upi_id'] ?>" placeholder="example@upi" class="w-full bg-gray-900 p-3 rounded text-white border border-gray-700">
        </div>
        <button type="submit" name="update_profile" class="w-full bg-yellow-500 text-gray-900 font-bold py-2 rounded">Update Profile</button>
    </form>
</div>
<form method="POST" action="profile.php">
    <input type="hidden" name="logout" value="1">
    <button type="submit" class="w-full bg-red-500 text-white font-bold py-3 rounded">Logout</button>
</form>
<?php require_once 'common/bottom.php'; ?>
