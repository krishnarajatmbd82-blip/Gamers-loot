<?php
require_once 'common/config.php';

try {
    // 1. Create Settings Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS site_settings (
        id INT PRIMARY KEY DEFAULT 1,
        admin_upi_id VARCHAR(255),
        qr_code_path VARCHAR(255)
    )");

    // Insert default row if not exists
    $pdo->exec("INSERT IGNORE INTO site_settings (id, admin_upi_id) VALUES (1, 'yourname@upi')");

    // 2. Create Deposits Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS deposits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        amount DECIMAL(10,2),
        txn_id VARCHAR(100),
        status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // 3. Create Withdrawals Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS withdrawals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        amount DECIMAL(10,2),
        status ENUM('Pending', 'Completed', 'Rejected') DEFAULT 'Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // 4. Update Users Table (Safe Check)
    $result = $pdo->query("SHOW COLUMNS FROM users LIKE 'upi_id'");
    if ($result->rowCount() == 0) {
        $pdo->exec("ALTER TABLE users ADD COLUMN upi_id VARCHAR(255) NULL");
    }

    echo "<div style='font-family:sans-serif; text-align:center; margin-top:50px;'>
            <h2 style='color:green;'>✅ Database schema updated successfully!</h2>
            <p>You can now safely delete this file and refresh your app.</p>
            <a href='index.php' style='color:blue;'>Go to Home</a>
          </div>";
} catch (PDOException $e) {
    die("Update Failed: " . $e->getMessage());
}
?>
$pdo->exec("ALTER TABLE participants ADD COLUMN player_game_id VARCHAR(100) NULL");
$pdo->exec("ALTER TABLE participants ADD COLUMN team_type ENUM('Solo', 'Duo', 'Squad') DEFAULT 'Solo'");
