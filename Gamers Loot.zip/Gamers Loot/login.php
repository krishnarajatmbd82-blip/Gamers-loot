<?php require_once 'common/header.php'; 
if(isLoggedIn()) { header("Location: index.php"); exit; }
$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];

    if ($action == 'login') {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: index.php"); exit;
        } else { $error = "Invalid username or password."; }
    } elseif ($action == 'signup') {
        $email = htmlspecialchars($_POST['email']);
        $hash = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, wallet_balance) VALUES (?, ?, ?, 50.00)");
            $stmt->execute([$username, $email, $hash]); // Give 50 bonus
            $success = "Account created! You received a ₹50 signup bonus. Please login.";
        } catch(PDOException $e) { $error = "Username or Email already exists."; }
    }
}
?>
<div class="mt-10">
    <div class="text-center mb-8">
        <i class="fa-solid fa-gamepad text-6xl text-yellow-500 mb-2"></i>
        <h1 class="text-3xl font-bold">Gamers Loot</h1>
    </div>
    <?php if($error) echo "<div class='bg-red-500 text-white p-3 rounded mb-4 text-sm'>$error</div>"; ?>
    <?php if($success) echo "<div class='bg-green-500 text-white p-3 rounded mb-4 text-sm'>$success</div>"; ?>
    
    <div id="login-form">
        <h2 class="text-xl font-bold mb-4">Login</h2>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="action" value="login">
            <input type="text" name="username" placeholder="Username" required class="w-full bg-gray-800 p-3 rounded text-white focus:outline-none focus:ring-2 focus:ring-yellow-500">
            <input type="password" name="password" placeholder="Password" required class="w-full bg-gray-800 p-3 rounded text-white focus:outline-none focus:ring-2 focus:ring-yellow-500">
            <button type="submit" class="w-full bg-yellow-500 text-gray-900 font-bold py-3 rounded">Log In</button>
        </form>
        <p class="text-center mt-4 text-gray-400">New here? <button onclick="document.getElementById('login-form').style.display='none'; document.getElementById('signup-form').style.display='block';" class="text-yellow-500">Sign up</button></p>
    </div>

    <div id="signup-form" style="display:none;">
        <h2 class="text-xl font-bold mb-4">Sign Up</h2>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="action" value="signup">
            <input type="text" name="username" placeholder="Username" required class="w-full bg-gray-800 p-3 rounded text-white focus:outline-none focus:ring-2 focus:ring-yellow-500">
            <input type="email" name="email" placeholder="Email Address" required class="w-full bg-gray-800 p-3 rounded text-white focus:outline-none focus:ring-2 focus:ring-yellow-500">
            <input type="password" name="password" placeholder="Password" required class="w-full bg-gray-800 p-3 rounded text-white focus:outline-none focus:ring-2 focus:ring-yellow-500">
            <button type="submit" class="w-full bg-yellow-500 text-gray-900 font-bold py-3 rounded">Create Account</button>
        </form>
        <p class="text-center mt-4 text-gray-400">Already have an account? <button onclick="document.getElementById('signup-form').style.display='none'; document.getElementById('login-form').style.display='block';" class="text-yellow-500">Log in</button></p>
    </div>
</div>
<?php require_once 'common/bottom.php'; ?>
