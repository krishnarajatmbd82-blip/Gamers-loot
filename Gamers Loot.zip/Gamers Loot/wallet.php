<?php require_once 'common/header.php'; 
$uid = $_SESSION['user_id'];
$msg = '';

// Fetch Admin Settings
$s_stmt = $pdo->query("SELECT * FROM site_settings WHERE id = 1");
$site = $s_stmt->fetch();

// 1. Handle Deposit Request
if (isset($_POST['req_deposit'])) {
    $amount = (float)$_POST['amount'];
    $txn = htmlspecialchars($_POST['txn_id']);
    if($amount >= 10) {
        $stmt = $pdo->prepare("INSERT INTO deposits (user_id, amount, txn_id) VALUES (?, ?, ?)");
        $stmt->execute([$uid, $amount, $txn]);
        $msg = "<div class='bg-green-500 text-white p-2 rounded mb-4'>Request Submitted! Pending verification.</div>";
    }
}

// 2. Handle Withdrawal Request
if (isset($_POST['req_withdraw'])) {
    $amount = (float)$_POST['amount'];
    $u_stmt = $pdo->prepare("SELECT wallet_balance, upi_id FROM users WHERE id = ?");
    $u_stmt->execute([$uid]);
    $user = $u_stmt->fetch();

    if (empty($user['upi_id'])) {
        $msg = "<div class='bg-red-500 text-white p-2 rounded mb-4'>Please save your UPI ID in Profile first!</div>";
    } elseif ($amount > $user['wallet_balance'] || $amount < 50) {
        $msg = "<div class='bg-red-500 text-white p-2 rounded mb-4'>Min withdrawal ₹50. Check balance.</div>";
    } else {
        $pdo->beginTransaction();
        $pdo->exec("UPDATE users SET wallet_balance = wallet_balance - $amount WHERE id = $uid");
        $stmt = $pdo->prepare("INSERT INTO withdrawals (user_id, amount) VALUES (?, ?)");
        $stmt->execute([$uid, $amount]);
        $pdo->commit();
        $msg = "<div class='bg-green-500 text-white p-2 rounded mb-4'>Withdrawal request sent!</div>";
    }
}

$tx_stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$tx_stmt->execute([$uid]);
$transactions = $tx_stmt->fetchAll();
?>

<style>
    .modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.8); z-index: 100; align-items: center; justify-content: center; padding: 20px; }
    .modal:target { display: flex; }
</style>

<?= $msg ?>

<div class="bg-gradient-to-r from-yellow-600 to-yellow-500 rounded-xl p-6 text-gray-900 shadow-lg mb-6">
    <p class="text-sm font-semibold mb-1">Total Balance</p>
    <h2 class="text-4xl font-bold">₹<?= number_format($balance, 2) ?></h2>
    <div class="flex gap-4 mt-6">
        <a href="#depositModal" class="w-1/2 bg-gray-900 text-white py-2 rounded font-bold text-sm text-center"><i class="fa-solid fa-plus mr-1"></i> Add Money</a>
        <a href="#withdrawModal" class="w-1/2 bg-white text-gray-900 py-2 rounded font-bold text-sm text-center"><i class="fa-solid fa-building-columns mr-1"></i> Withdraw</a>
    </div>
</div>

<div id="depositModal" class="modal">
    <div class="bg-gray-800 p-6 rounded-xl w-full max-w-sm border border-gray-700">
        <div class="flex justify-between mb-4">
            <h3 class="font-bold">Add Money</h3>
            <a href="#" class="text-gray-400"><i class="fa-solid fa-xmark"></i></a>
        </div>
        <div class="text-center mb-4">
            <p class="text-xs text-gray-400 mb-2">Scan & Pay to Admin</p>
            <img src="<?= $site['qr_code_path'] ?>" class="w-40 h-40 mx-auto rounded border-2 border-yellow-500 p-1 mb-2">
            <p class="text-sm font-bold text-yellow-500 select-all"><?= $site['admin_upi_id'] ?></p>
        </div>
        <form method="POST" class="space-y-3">
            <input type="number" name="amount" placeholder="Amount Paid (₹)" required class="w-full bg-gray-900 p-2 rounded text-white border border-gray-700">
            <input type="text" name="txn_id" placeholder="UPI Transaction ID" required class="w-full bg-gray-900 p-2 rounded text-white border border-gray-700">
            <button type="submit" name="req_deposit" class="w-full bg-yellow-500 text-gray-900 font-bold py-2 rounded">Submit Request</button>
        </form>
    </div>
</div>

<div id="withdrawModal" class="modal">
    <div class="bg-gray-800 p-6 rounded-xl w-full max-w-sm border border-gray-700">
        <div class="flex justify-between mb-4">
            <h3 class="font-bold">Withdraw Money</h3>
            <a href="#" class="text-gray-400"><i class="fa-solid fa-xmark"></i></a>
        </div>
        <form method="POST" class="space-y-4">
            <p class="text-xs text-gray-400">Withdrawal will be sent to your saved UPI ID.</p>
            <input type="number" name="amount" placeholder="Amount to Withdraw (₹)" required class="w-full bg-gray-900 p-2 rounded text-white border border-gray-700">
            <button type="submit" name="req_withdraw" class="w-full bg-yellow-500 text-gray-900 font-bold py-2 rounded">Request Withdrawal</button>
        </form>
    </div>
</div>

<h3 class="font-bold text-lg mb-3">Transaction History</h3>
<div class="bg-gray-800 rounded-lg overflow-hidden">
    <?php foreach($transactions as $tx): ?>
    <div class="p-4 border-b border-gray-700 flex justify-between items-center last:border-0">
        <div><p class="text-sm font-bold"><?= $tx['description'] ?></p><p class="text-xs text-gray-400"><?= date('d M, h:i A', strtotime($tx['created_at'])) ?></p></div>
        <div class="<?= $tx['type'] == 'credit' ? 'text-green-400' : 'text-red-400' ?> font-bold"><?= $tx['type'] == 'credit' ? '+' : '-' ?>₹<?= $tx['amount'] ?></div>
    </div>
    <?php endforeach; ?>
</div>
<?php require_once 'common/bottom.php'; ?>
