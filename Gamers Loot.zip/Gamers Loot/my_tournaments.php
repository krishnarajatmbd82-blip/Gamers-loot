<?php require_once 'common/header.php'; 
$uid = $_SESSION['user_id'];
$tab = $_GET['tab'] ?? 'live';

$live_sql = "SELECT t.* FROM tournaments t JOIN participants p ON t.id = p.tournament_id WHERE p.user_id = ? AND t.status = 'Upcoming' ORDER BY t.match_time ASC";
$comp_sql = "SELECT t.* FROM tournaments t JOIN participants p ON t.id = p.tournament_id WHERE p.user_id = ? AND t.status = 'Completed' ORDER BY t.match_time DESC";

$stmt = $pdo->prepare($tab == 'live' ? $live_sql : $comp_sql);
$stmt->execute([$uid]);
$matches = $stmt->fetchAll();
?>
<h2 class="text-xl font-bold mb-4">My Tournaments</h2>
<div class="flex mb-4 border-b border-gray-700">
    <a href="?tab=live" class="w-1/2 text-center py-2 <?= $tab == 'live' ? 'border-b-2 border-yellow-500 text-yellow-500' : 'text-gray-400' ?>">Live/Upcoming</a>
    <a href="?tab=completed" class="w-1/2 text-center py-2 <?= $tab == 'completed' ? 'border-b-2 border-yellow-500 text-yellow-500' : 'text-gray-400' ?>">Completed</a>
</div>

<div class="space-y-4">
    <?php foreach($matches as $t): ?>
    <div class="bg-gray-800 p-4 rounded-lg shadow border border-gray-700">
        <h3 class="font-bold text-lg text-yellow-500"><?= htmlspecialchars($t['title']) ?></h3>
        <p class="text-xs text-gray-400 mb-2"><?= date('d M Y, h:i A', strtotime($t['match_time'])) ?></p>
        
        <?php if($tab == 'live'): ?>
            <div class="bg-gray-900 p-3 rounded mt-2">
                <p class="text-sm font-bold text-center mb-1 text-gray-300">Room Details</p>
                <?php if($t['room_id']): ?>
                    <p class="text-sm">ID: <span class="text-yellow-500 font-mono"><?= htmlspecialchars($t['room_id']) ?></span></p>
                    <p class="text-sm">Pass: <span class="text-yellow-500 font-mono"><?= htmlspecialchars($t['room_password']) ?></span></p>
                <?php else: ?>
                    <p class="text-xs text-center text-gray-500">Details will be shared 15 mins before match.</p>
                <?php endif; ?>
            </div>
        <?php else: ?>
             <div class="mt-2 bg-gray-900 p-2 rounded text-center">
                 <p class="text-sm text-green-400 font-bold">Match Completed</p>
             </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <?php if(!$matches): ?>
        <p class="text-gray-400 text-center mt-10">No records found.</p>
    <?php endif; ?>
</div>
<?php require_once 'common/bottom.php'; ?>
