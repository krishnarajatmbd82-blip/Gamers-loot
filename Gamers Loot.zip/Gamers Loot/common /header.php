<?php
require_once 'config.php';
if (!isLoggedIn() && basename($_SERVER['PHP_SELF']) != 'login.php') {
    header("Location: login.php");
    exit();
}
$balance = 0;
if (isLoggedIn()) {
    $stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $balance = $stmt->fetchColumn() ?: 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Gamers Loot</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { user-select: none; -webkit-user-select: none; -webkit-touch-callout: none; overflow-x: hidden; }
        .app-container { max-width: 480px; margin: 0 auto; min-height: 100vh; background-color: #111827; color: white; position: relative; padding-bottom: 70px; }
    </style>
    <script>
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('selectstart', e => e.preventDefault());
    </script>
</head>
<body class="bg-gray-900">
<div class="app-container shadow-2xl overflow-hidden">
    <?php if(basename($_SERVER['PHP_SELF']) != 'login.php'): ?>
    <div class="bg-gray-800 p-4 flex justify-between items-center sticky top-0 z-50 border-b border-gray-700">
        <h1 class="text-xl font-bold text-yellow-500"><i class="fa-solid fa-gamepad mr-2"></i>Gamers Loot</h1>
        <div class="bg-gray-700 px-3 py-1 rounded-full text-sm font-semibold text-green-400">
            <i class="fa-solid fa-wallet mr-1"></i> ₹<?= number_format($balance, 2) ?>
        </div>
    </div>
    <?php endif; ?>
    <div class="p-4">
