    </div> <?php if(basename($_SERVER['PHP_SELF']) != 'login.php'): ?>
    <div class="bg-gray-800 border-t border-gray-700 fixed bottom-0 w-full max-w-[480px] flex justify-around p-3 z-50">
        <a href="index.php" class="text-center <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'text-yellow-500' : 'text-gray-400' ?>"><i class="fa-solid fa-house text-xl block"></i><span class="text-xs">Home</span></a>
        <a href="my_tournaments.php" class="text-center <?= basename($_SERVER['PHP_SELF']) == 'my_tournaments.php' ? 'text-yellow-500' : 'text-gray-400' ?>"><i class="fa-solid fa-trophy text-xl block"></i><span class="text-xs">Matches</span></a>
        <a href="wallet.php" class="text-center <?= basename($_SERVER['PHP_SELF']) == 'wallet.php' ? 'text-yellow-500' : 'text-gray-400' ?>"><i class="fa-solid fa-wallet text-xl block"></i><span class="text-xs">Wallet</span></a>
        <a href="profile.php" class="text-center <?= basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'text-yellow-500' : 'text-gray-400' ?>"><i class="fa-solid fa-user text-xl block"></i><span class="text-xs">Profile</span></a>
    </div>
    <?php endif; ?>
</div>
</body>
</html>
