<?php
session_start();
$host = '127.0.0.1';
$db   = 'gamers_loot';
$user = 'root';
$pass = 'root'; // Change if needed

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed.");
}

function isLoggedIn() { return isset($_SESSION['user_id']); }
function isAdminLoggedIn() { return isset($_SESSION['admin_id']); }
?>
